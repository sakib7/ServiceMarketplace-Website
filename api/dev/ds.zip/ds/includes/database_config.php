<?php
/* $database_user = "ds2016_user_ad";
$database_pass = "@LexhlaEzPKF";
$database_name = "ds2016_dhakasetup";
$database_host = "192.185.2.151"; */

$database_user = "root";
$database_pass = "";
$database_name = "ds2016_dhakasetup";
$database_host = "localhost";
?>