                <!-- footer content -->
                <footer>
                    <div class="pull-right">
                        <p><a href="http://dhakasetup.com/">Dhakasetup.com</a> | <a href="http://dhakasetup.com/dashboard.php">Admin Panel</a></p>
                    </div>
                    <div class="clearfix"></div>
                </footer>
                <!-- /footer content -->
            </div>
        </div>
    </div>


    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- date js -->
    <script src="js/date.js"></script>
    <!-- date range picker js -->
    <script src="js/daterangepicker.js"></script>
    <!-- switchery js -->
    <script src="js/switchery.min.js"></script>
    <!-- validator js -->
    <script type="text/javascript" src="js/validator.min.js"></script>
    <!-- weather js -->
    <script src="js/simpleWeather.min.js"></script>
    <!-- date picker js -->
    <script type="text/javascript" src="js/datepicker.js"></script>
    <!-- moment js -->
    <script src="js/moment.min.js"></script>
    <!-- autosize js -->
    <script src="js/autosize.min.js"></script>
    <!-- select js -->
    <script src="js/EditableSelect.js"></script>
    <!-- custom js -->
    <script src="js/custom.min.js"></script>
    

    <!-- <script>
        $(document).ready(function () {
            $('#closed-date').daterangepicker({
                singleDatePicker: true,
                calender_style: "picker_4"
            }, function (start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#delivered-date').daterangepicker({
                singleDatePicker: true,
                calender_style: "picker_4"
            }, function (start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
            });
        });
    </script>

    <script>
        $(document).ready(function () {
            
            $('.logouttab').click(function(e){
                    e.prevenDefault();
                    var address = $('.logouttab').attr('href');
                    window.location.href = address;
                });
            
            $('#warranty-date').daterangepicker({
                singleDatePicker: true,
                calender_style: "picker_4"
            }, function (start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
            });
        });
    </script> -->